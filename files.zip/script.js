/* ============================================================
   SCRIPT.JS — Yash Jogani Portfolio ★ ENHANCED ★
   Features: particle canvas, magnetic cursor, magnetic buttons,
   typing animation, reveal, skill bars, counters, tilt cards,
   contact form, nav active links, back-to-top
   ============================================================ */

'use strict';

/* ── Helpers ─────────────────────────────────────────────── */
const $ = (s, c = document) => c.querySelector(s);
const $$ = (s, c = document) => [...c.querySelectorAll(s)];

/* ── DOM ──────────────────────────────────────────────────── */
const navbar      = $('#navbar');
const hamburger   = $('#hamburger');
const drawer      = $('#drawer');
const backTop     = $('#backTop');
const contactForm = $('#contactForm');
const formSuccess = $('#formSuccess');
const yearEl      = $('#year');
const canvas      = $('#heroCanvas');

/* ── Year ─────────────────────────────────────────────────── */
if (yearEl) yearEl.textContent = new Date().getFullYear();

/* ================================================================
   PARTICLE CANVAS — neural network feel
================================================================ */
(function initParticles() {
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W, H, particles, mouse = { x: -1000, y: -1000 };

  const COLORS   = ['rgba(0,229,255,', 'rgba(176,111,255,', 'rgba(61,139,255,'];
  const N_BASE   = 80;
  const CONNECT  = 130;   // max distance to draw a line
  const MOUSE_R  = 180;   // mouse influence radius

  function resize() {
    W = canvas.width  = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
    buildParticles();
  }

  function buildParticles() {
    const n = Math.min(N_BASE, Math.floor((W * H) / 14000));
    particles = Array.from({ length: n }, () => ({
      x:   Math.random() * W,
      y:   Math.random() * H,
      vx:  (Math.random() - .5) * .4,
      vy:  (Math.random() - .5) * .4,
      r:   Math.random() * 1.8 + .6,
      col: COLORS[Math.floor(Math.random() * COLORS.length)],
    }));
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);

    // Update + draw dots
    for (const p of particles) {
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0 || p.x > W) p.vx *= -1;
      if (p.y < 0 || p.y > H) p.vy *= -1;

      // Mouse repulsion (subtle)
      const dx = p.x - mouse.x;
      const dy = p.y - mouse.y;
      const dist = Math.hypot(dx, dy);
      if (dist < MOUSE_R) {
        const force = (MOUSE_R - dist) / MOUSE_R * .8;
        p.x += (dx / dist) * force;
        p.y += (dy / dist) * force;
      }

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = p.col + '.55)';
      ctx.fill();
    }

    // Draw connecting lines
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const d  = Math.hypot(dx, dy);
        if (d < CONNECT) {
          const alpha = (1 - d / CONNECT) * .18;
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = particles[i].col + alpha + ')';
          ctx.lineWidth = .8;
          ctx.stroke();
        }
      }
    }

    requestAnimationFrame(draw);
  }

  window.addEventListener('resize', resize, { passive: true });
  window.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
  }, { passive: true });

  resize();
  draw();
})();

/* ================================================================
   CUSTOM CURSOR GLOW  (desktop only)
================================================================ */
(function initCursorGlow() {
  if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;

  const glow = document.createElement('div');
  Object.assign(glow.style, {
    position: 'fixed',
    width: '450px',
    height: '450px',
    borderRadius: '50%',
    pointerEvents: 'none',
    zIndex: '1',
    background: 'radial-gradient(circle, rgba(0,229,255,0.04) 0%, transparent 65%)',
    transform: 'translate(-50%, -50%)',
    transition: 'left .14s ease, top .14s ease',
    willChange: 'left, top',
  });
  document.body.appendChild(glow);

  document.addEventListener('mousemove', (e) => {
    glow.style.left = e.clientX + 'px';
    glow.style.top  = e.clientY + 'px';
  }, { passive: true });
})();

/* ================================================================
   MAGNETIC BUTTON EFFECT
================================================================ */
(function initMagneticButtons() {
  if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;

  $$('.btn').forEach(btn => {
    btn.addEventListener('mousemove', (e) => {
      const rect = btn.getBoundingClientRect();
      const cx   = rect.left + rect.width / 2;
      const cy   = rect.top  + rect.height / 2;
      const dx   = (e.clientX - cx) * .25;
      const dy   = (e.clientY - cy) * .25;
      btn.style.transform = `translate(${dx}px, ${dy}px) translateY(-3px)`;
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.transform = '';
    });
  });
})();

/* ================================================================
   NAV — scroll state
================================================================ */
function onNavScroll() {
  navbar.classList.toggle('scrolled', window.scrollY > 40);
}
window.addEventListener('scroll', onNavScroll, { passive: true });
onNavScroll();

/* ================================================================
   MOBILE MENU
================================================================ */
hamburger.addEventListener('click', () => {
  const open = drawer.classList.toggle('open');
  hamburger.classList.toggle('active', open);
  hamburger.setAttribute('aria-expanded', String(open));
  document.body.style.overflow = open ? 'hidden' : '';
});

$$('.drawer__link').forEach(l => l.addEventListener('click', closeMenu));
document.addEventListener('click', (e) => {
  if (!drawer.contains(e.target) && !hamburger.contains(e.target)) closeMenu();
});

function closeMenu() {
  drawer.classList.remove('open');
  hamburger.classList.remove('active');
  hamburger.setAttribute('aria-expanded', 'false');
  document.body.style.overflow = '';
}

/* ================================================================
   SMOOTH SCROLL
================================================================ */
$$('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = $(a.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    closeMenu();
    target.scrollIntoView({ behavior: 'smooth' });
  });
});

/* ================================================================
   SCROLL-REVEAL
================================================================ */
const revealObs = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('revealed');
      revealObs.unobserve(e.target);
    }
  });
}, { threshold: .1, rootMargin: '0px 0px -45px 0px' });

$$('.reveal').forEach(el => revealObs.observe(el));

/* ================================================================
   SKILL BAR ANIMATION
================================================================ */
const barObs = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      const fill = $('.skill-card__fill', e.target);
      if (fill) setTimeout(() => { fill.style.width = fill.dataset.pct + '%'; }, 420);
      barObs.unobserve(e.target);
    }
  });
}, { threshold: .3 });

$$('.skill-card').forEach(c => barObs.observe(c));

/* ================================================================
   COUNTER ANIMATION
================================================================ */
function animateCount(el, to, dur = 1500) {
  const start = performance.now();
  const raf = (now) => {
    const p = Math.min((now - start) / dur, 1);
    const ease = 1 - Math.pow(1 - p, 3);
    el.textContent = Math.round(to * ease).toLocaleString();
    if (p < 1) requestAnimationFrame(raf);
  };
  requestAnimationFrame(raf);
}

const countObs = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      $$('.about__stat-num', e.target).forEach(n => animateCount(n, +n.dataset.target));
      countObs.unobserve(e.target);
    }
  });
}, { threshold: .4 });

const visual = $('.about__visual');
if (visual) countObs.observe(visual);

/* ================================================================
   BACK TO TOP
================================================================ */
window.addEventListener('scroll', () => {
  backTop.classList.toggle('visible', window.scrollY > 400);
}, { passive: true });

if (backTop) backTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

/* ================================================================
   ACTIVE NAV LINK
================================================================ */
const sections = $$('section[id]');
const navLinks  = $$('.nav__link');

const secObs = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      const id = e.target.id;
      navLinks.forEach(l => {
        const active = l.getAttribute('href') === `#${id}`;
        l.style.color = active ? 'transparent' : '';
        // The ::before pseudo-element handles gradient text via CSS on hover;
        // for active state we toggle a class
        l.classList.toggle('is-active', active);
      });
    }
  });
}, { threshold: .38 });

sections.forEach(s => secObs.observe(s));

// Inject active link CSS
const activeStyle = document.createElement('style');
activeStyle.textContent = `
  .nav__link.is-active { color: transparent !important; }
  .nav__link.is-active::before { opacity: 1 !important; }
`;
document.head.appendChild(activeStyle);

/* ================================================================
   PROJECT CARD — 3D TILT
================================================================ */
$$('.project-card, .skill-card').forEach(card => {
  card.addEventListener('mousemove', (e) => {
    const r   = card.getBoundingClientRect();
    const x   = e.clientX - r.left;
    const y   = e.clientY - r.top;
    const cx  = r.width  / 2;
    const cy  = r.height / 2;
    const rX  = ((y - cy) / cy) * -7;
    const rY  = ((x - cx) / cx) *  7;
    card.style.transform = `perspective(900px) rotateX(${rX}deg) rotateY(${rY}deg) translateY(-8px) scale(1.01)`;
  });
  card.addEventListener('mouseleave', () => { card.style.transform = ''; });
});

/* ================================================================
   CONTACT FORM
================================================================ */
if (contactForm) {
  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const nameEl = $('#name');
    const mailEl = $('#email');
    const msgEl  = $('#message');
    let valid = true;

    [nameEl, mailEl, msgEl].forEach(f => {
      f.style.borderColor = '';
      if (!f.value.trim()) { f.style.borderColor = 'rgba(255,92,205,.6)'; valid = false; }
    });
    if (mailEl.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mailEl.value)) {
      mailEl.style.borderColor = 'rgba(255,92,205,.6)'; valid = false;
    }
    if (!valid) {
      formSuccess.textContent = '⚠ Please fill all fields correctly.';
      formSuccess.style.color = 'var(--neon-pink)';
      return;
    }

    const btn = $('button[type="submit"]', contactForm);
    btn.disabled = true;
    btn.innerHTML = '<i class="ph ph-circle-notch"></i> Sending…';
    btn.querySelector('i').style.animation = 'spin .7s linear infinite';

    await new Promise(r => setTimeout(r, 1300));

    formSuccess.textContent = '✓ Message sent! I\'ll reply within 24 hours.';
    formSuccess.style.color = 'var(--neon-green)';
    contactForm.reset();
    btn.disabled = false;
    btn.innerHTML = '<i class="ph ph-paper-plane-tilt"></i> Send Message';
    setTimeout(() => { formSuccess.textContent = ''; }, 5500);
  });
}

/* ================================================================
   TYPING ANIMATION — hero eyebrow
================================================================ */
(function typing() {
  const el = $('#typingText');
  if (!el) return;
  const phrases = [
    'sys.init("portfolio") → online',
    'model.fit(curiosity=True)',
    'loss → 0.0001 ✓ converged',
    'cv2.VideoCapture(0) → running',
    'print("Hello, World!")',
  ];
  let pi = 0, ci = phrases[0].length, del = false, wait = false;

  function tick() {
    if (wait) return;
    const cur = phrases[pi];
    if (!del) {
      if (ci < cur.length) { el.textContent = cur.slice(0, ++ci); setTimeout(tick, 55); }
      else { wait = true; setTimeout(() => { wait = false; del = true; tick(); }, 2600); }
    } else {
      if (ci > 0) { el.textContent = cur.slice(0, --ci); setTimeout(tick, 28); }
      else { del = false; pi = (pi + 1) % phrases.length; setTimeout(tick, 400); }
    }
  }
  setTimeout(tick, 2200);
})();

/* ================================================================
   CSS: spin animation for submit button
================================================================ */
const spinStyle = document.createElement('style');
spinStyle.textContent = `@keyframes spin { to { transform: rotate(360deg); } }`;
document.head.appendChild(spinStyle);

/* ================================================================
   HERO ENTRANCE — stagger sections slightly on load
================================================================ */
window.addEventListener('DOMContentLoaded', () => {
  // Force initial reveal check
  $$('.reveal').forEach(el => {
    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight * .92) el.classList.add('revealed');
  });
});
